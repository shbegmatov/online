<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
  <title>J&M schooll/Onlayin kurs markazi</title>
  <link rel="icon" type="text/css" href="img/logo.jpg">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
 <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.css">
</head>
<body onload="MyFunction()" style="margin:0;">
<div id="loader">
	
</div>
	<section style="display:none;" id="myDiv" class="animate-bottom">
		<nav class="navbar navbar-expand-md  navbar-dark fixed-top">
		  <a class="navbar-brand" href="#"><img src="img/logo.jpg" id="logo"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <div  onclick="myFunction(this)">
			  <div class="bar1"></div>
			  <div class="bar2"></div>
			  <div class="bar3"></div>
			</div>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item">
		        <a class="nav-link text-white" href="#"><i class="fas fa-user"></i> Kirish</a>
		      </li>
			 <li class="nav-item dropdown">
		      <a class="nav-link dropdown-toggle text-white" href="#" id="navbardrop" data-toggle="dropdown">
		        <img src="img/uzb.png" id="bayroq">
		      </a>
		      <div class="dropdown-menu">
		        <a class="dropdown-item" href="#"><img src="img/uzb.png" id="bayroq">UZ</a>
		        <a class="dropdown-item" href="#"><img src="img/rassiya.png" id="bayroq">RU</a>
		        <a class="dropdown-item" href="#"><img src="img/amerika.jpg" id="bayroq">ENG</a>
		      </div>
		    </li>
		      <li class="nav-item">
		        <a class="nav-link text-white" href="#">Registratsiya</a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link text-white" href="#">Siniv dars</a>
		      </li>
		    </ul>
		  </div>  
		</nav>
		<header>
		 <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
		    <ol class="carousel-indicators">
		      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
		      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
		      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
		    </ol>
		    <div class="carousel-inner" role="listbox">
		      <!-- Slide One - Set the background image for this slide in the line below -->
		      <div class="carousel-item active" style="background-image: url('https://source.unsplash.com/LAaSoL0LrYs/1920x1080')">
		        <div class="carousel-caption d-none d-md-block">
		          <h2 class="display-4">First Slide</h2>
		          <p class="lead">This is a description for the first slide.</p>
		        </div>
		      </div>
		      <!-- Slide Two - Set the background image for this slide in the line below -->
		      <div class="carousel-item" style="background-image: url('https://source.unsplash.com/bF2vsubyHcQ/1920x1080')">
		        <div class="carousel-caption d-none d-md-block">
		          <h2 class="display-4">Second Slide</h2>
		          <p class="lead">This is a description for the second slide.</p>
		        </div>
		      </div>
		      <!-- Slide Three - Set the background image for this slide in the line below -->
		      <div class="carousel-item" style="background-image: url('https://source.unsplash.com/szFUQoyvrxM/1920x1080')">
		        <div class="carousel-caption d-none d-md-block">
		          <h2 class="display-4">Third Slide</h2>
		          <p class="lead">This is a description for the third slide.</p>
		        </div>
		      </div>
		    </div>
		    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		          <span class="sr-only">Previous</span>
		        </a>
		    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		          <span class="carousel-control-next-icon" aria-hidden="true"></span>
		          <span class="sr-only">Next</span>
		        </a>
		  </div>
		</header>


				<!--Section-->
				<section>
					<div class="container">

			<!-- Portfolio Item Heading -->
			<h1 class="my-4">Page Heading
			<small>Secondary Text</small>
			</h1>

			<!-- Portfolio Item Row -->
			<div class="row">

			<div class="col-md-8">
			  <video class="img-fluid" autoplay muted loop id="myVideo">
				  <source src="css/vedio/reklama.mp4" type="video/mp4">
				  Your browser does not support HTML5 video.
				</video>
			</div>

			<div class="col-md-4">
			  <h3 class="my-3">Project Description</h3>
			  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Mauris ultricies, justo eu convallis placerat, felis enim.</p>
			  <h3 class="my-3">Project Details</h3>
			  <ul>
			    <li>Lorem Ipsum</li>
			    <li>Dolor Sit Amet</li>
			    <li>Consectetur</li>
			    <li>Adipiscing Elit</li>
			  </ul>
			</div>

			</div>
			<!-- /.row -->

			<!-- Related Projects Row -->
			<h3 class="my-4">Related Projects</h3>

			<div class="row">

			<div class="col-md-3 col-sm-6 mb-4">
			  <a href="#">
			        <img class="img-fluid" src="img/1.jpg" alt="">
			      </a>
			</div>

			<div class="col-md-3 col-sm-6 mb-4">
			  <a href="#">
			        <img class="img-fluid" src="img/2.jpg" alt="">
			      </a>
			</div>

			<div class="col-md-3 col-sm-6 mb-4">
			  <a href="#">
			        <img class="img-fluid" src="img/3.jpg" alt="">
			      </a>
			</div>

			<div class="col-md-3 col-sm-6 mb-4">
			  <a href="#">
			        <img class="img-fluid" src="img/4.jpg" alt="">
			      </a>
			</div>

			</div>
			<!-- /.row -->

			</div>
			<!-- /.container -->
		</section>

		<section>
			<div class="container">

		  <!-- Page Heading -->
		  <h1 class="my-4">Page Heading
		    <small>Secondary Text</small>
		  </h1>

		  <div class="row">
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techir4.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur eum quasi sapiente nesciunt? Voluptatibus sit, repellat sequi itaque deserunt, dolores in, nesciunt, illum tempora ex quae? Nihil, dolorem!</p>
		        </div>
		      </div>
		    </div>
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techer1.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		        </div>
		      </div>
		    </div>
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techir2.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos quisquam, error quod sed cumque, odio distinctio velit nostrum temporibus necessitatibus et facere atque iure perspiciatis mollitia recusandae vero vel quam!</p>
		        </div>
		      </div>
		    </div>
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techir3.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		        </div>
		      </div>
		    </div>
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techir4.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
		        </div>
		      </div>
		    </div>
		    <div class="col-lg-4 col-sm-6 mb-4">
		      <div class="card h-100">
		        <a href="#"><img class="card-img-top" src="img/techir2.jpg" alt=""></a>
		        <div class="card-body">
		          <h4 class="card-title">
		            <a href="#">Ticher</a>
		          </h4>
		          <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque earum nostrum suscipit ducimus nihil provident, perferendis rem illo, voluptate atque, sit eius in voluptates, nemo repellat fugiat excepturi! Nemo, esse.</p>
		        </div>
		      </div>
		    </div>
		  </div>

		</div>
		<!-- /.container -->
		</section>
		<div class="container" id="messeg1">
						  <!-- Button to Open the Modal -->
							<i id="messeg" class="fas fa-comment text-danger fa-5x fixed-top" data-toggle="modal" data-target="#myModal"></i>
						  <!-- The Modal -->
						  <div class="modal" id="myModal">
						    <div class="modal-dialog">
						      <div class="modal-content">
						      
						        <!-- Modal Header -->
						        <div class="modal-header bg-danger">
						          <p class="modal-title">Adminga murojat</p><br>
						          <p class="text-center">Har qanaqa savolga javob topib berishga harkat qilamiz</p>
						          <button type="button" class="close" data-dismiss="modal">&times;</button>
						        </div>
						        
						        <!-- Modal body -->
						        <div class="modal-body border m-3">
						        	<form>
							          <input type="text" name="user" placeholder="Username.." class="form-control">
							          <input type="email" name="email" placeholder="Email.." class="form-control my-5">
										<textarea name="murojat" class="form-control" placeholder="Adminga murojat.." style="overflow-x: hidden;">
										</textarea>
									</form>
						        </div>
						        
						        <!-- Modal footer -->
						        <div class="modal-footer">
						          <button type="button" class="btn btn-danger"><i class="fab fa-telegram-plane"></i></button>
						        </div>
						        
						      </div>
						    </div>
						  </div>
			</div>
		<footer id="sticky-footer" class="py-4 bg-dark text-white-50">
		    <div class="container text-center">
		      <small>Copyright &copy;Your Website</small>
		    </div>
		  </footer>
	</section>
		<script type="text/javascript" src="js/main.js"></script>
</body>
</html>